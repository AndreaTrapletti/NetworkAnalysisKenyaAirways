
#################################################
####### Network analysis 2019              #######
#################################################
#######################
####### PART 1 #######
#######################
rm(list = ls())

par(mar = c(1, 1, 1, 3))
setwd("G:\\Il mio Drive\\UNIBG\\Economia delle reti e dei servizi\\progetto_ERS\\tentativo1")
nodes<-read.csv("KENYA_NODES2019_finale.csv")
links<-read.csv("KENYA_EDGES2019_finale.csv")

nrow(nodes)
length(unique(nodes$id))
nrow(links)
nrow(unique(links[,c("DepAirportCode","ArrAirportCode")]))
### Graphical representation
library(igraph)
net<-graph_from_data_frame(d=links,vertices=nodes,directed=T)

as_edgelist(net,names=T)
as_data_frame(net,what="edges")
as_data_frame(net,what="vertices")

####Plot
plot(net,edge.arrow.size=.1,vertex.size=3,vertex.label.cex=.01, main = "Mappatura dei nodi. 2019")
plot(net,edge.arrow.size=.1,vertex.label=V(net)$Dep,vertex.size=.5,vertex.label.cex=.5, main = "Mappatura dei nodi (Codice aeroporto). 2019")
plot(net, edge.arrow.size=.1, vertex.shape="none", vertex.label=V(net)$Dep, vertex.size=3,vertex.label.font=2, vertex.label.color="gray40",vertex.label.cex=.5, edge.color="gray85", main = "Mappatura dei nodi (Codice aeroporto). 2019")

####Plot with curved links
plot(net,edge.arrow.size=.1,vertex.size=.9,edge.curved=.1,vertex.label.cex=.6,main = "Mappatura dei nodi (Codice aeroporto). Con archi curvi. 2019")

####Plot with yellow nodes
plot(net,edge.arrow.size=.1,edge.curved=0,vertex.color="orange",vertex.frame.color="#555555",vertex.label=V(net)$Dep,vertex.size=4.9,vertex.label.color="black",vertex.label.cex=.5, main = "Mappatura dei nodi (Codice aeroporto). 2019")

####Generation of the color on the basis of the Continent
V(net)$type <- 6
V(net)$type[V(net)$Continent=="Europe"] <- 1
V(net)$type[V(net)$Continent=="Africa"] <- 2
V(net)$type[V(net)$Continent=="Middle East"] <- 3
V(net)$type[V(net)$Continent=="Asia"] <- 4
V(net)$type[V(net)$Continent=="America"] <- 5

colrs<-c("gold", "green", "lightblue", "pink","tomato","black")
V(net)$color<-colrs[V(net)$type]
plot(net,edge.arrow.size=.1,edge.curved=0,vertex.label=V(net)$Dep,vertex.size=4.9,vertex.label.color="black",pt.bg=colrs,vertex.label.cex=.5,vertex.frame.color="white", main= "Mappatura dei nodi, colorati per continente. 2019")
plot(net,edge.arrow.size=.05,edge.curved=0,vertex.label=V(net)$Dep,vertex.size=5,pt.bg=colrs,vertex.label.cex=.005,vertex.frame.color="white", main= "Mappatura dei nodi, colorati per continente. 2019")

V(net)$label<-V(net)$Dep
E(net)$width<-E(net)$POSTI_TOT/10000
V(net)$size<- (log(V(net)$TOTseats)+1)

E(net)$arrow.size<-.05
E(net)$edge.color<-"gray80"

par(mar = c(1, 1, 1, 3))
plot(net,vertex.label.cex=.5, main = "Grandezza nodi per posti totali, spessore archi per posti della tratta. 2019")

#analisi lunghezza nodi
netKM <- net
V(netKM)$size<- 5
E(netKM)$width<-E(net)$GCD/10000 +1
cut.offKM<-mean(links$GCD)/10000 + 1
netKM.sp<-delete_edges(netKM,E(netKM)[(GCD/10000 + 0.75)<cut.offKM])
plot(netKM,vertex.label.cex=.5, main="Spessore degli archi dato da lunghezza della tratta. 2019")
plot(netKM.sp,vertex.label.cex=.5, main="Mappa con i collegamenti tra i nodi più distanti. 2019")

par(mar = c(5,5,5,5))
### Sliming down the nodes
hist(nodes$TOTseats, main="Istogramma della grandezza dei nodi per posti totali. 2019", xlab = "posti totali del nodo", ylab = "numero di nodi")
mean(nodes$TOTseats)
sd(nodes$TOTseats)
cut.off2 <- mean(nodes$TOTseats)
net.sp2 <- net - V(net)[(V(net)$TOTseats < cut.off2)]
par(mar = c(1,1,1,1))
plot(net.sp2,edge.arrow.size=.1,edge.color="orange",vertex.color="white",vertex.label.cex=.7, main="mappa dei nodi con il numero di posti totali maggiori della media dei posti totali. 2019")
par(mar = c(5,5,5,5))
postiN <- V(net.sp2)$TOTseats
hist(postiN, main="Istogramma della grandezza dei nodi per posti totali, \n considerando solo i nodi con i posti totali maggiori alla media. 2019", xlab = "posti totali del nodo", ylab = "numero di nodi")

#### Sliming down the network
hist(links$POSTI_TOT, main="Istogramma della grandezza delle tratte per posti. 2019", xlab = "posti totali delle tratte", ylab = "numero delle tratte")
mean(links$POSTI_TOT)
sd(links$POSTI_TOT)
cut.off<-mean(links$POSTI_TOT)
net.sp<-delete_edges(net,E(net)[POSTI_TOT<cut.off])
par(mar = c(1,1,1,1))
plot(net.sp,edge.arrow.size=.1,edge.color="orange",vertex.color="white",vertex.label.cex=.3,main="mappa delle tratte con posti totali di tratta maggiori alla media. 2019")
par(mar = c(5,5,5,5))
postiE <- E(net.sp)$POSTI_TOT
hist(postiE, main="Istogramma della grandezza delle tratte per posti, \nconsiderando solo le tratte con i posti totali superiori alla media. 2019", xlab = "posti totali della tratta", ylab = "numero delle tratte")

par(mar = c(1, 1, 1, 1))
E(net)$width<-1.5
net.af<-net-V(net)[(V(net)$Continent=="Europe") | (V(net)$Continent=="America") | (V(net)$Continent=="Asia") | (V(net)$Continent=="Middle East")]
net.e<-net-V(net)[V(net)$Continent=="Africa" | V(net)$Continent=="America" | V(net)$Continent=="Asia" | V(net)$Continent=="Middle East"]
net.am<-net-V(net)[V(net)$Continent=="Europe" | V(net)$Continent=="Africa" | V(net)$Continent=="Asia" | V(net)$Continent=="Middle East"]
net.as<-net-V(net)[V(net)$Continent=="Europe" | V(net)$Continent=="America" | V(net)$Continent=="Africa" | V(net)$Continent=="Middle East"]
net.me<-net-V(net)[(V(net)$Continent=="Europe") | (V(net)$Continent=="America") | (V(net)$Continent=="Asia") | (V(net)$Continent=="Africa")]
net.af

dev.off()
plot(net.af,vertex.color="green",main="AFRICA. 2019",vertex.label.cex=.6)
plot(net.me,edge.arrow.size=.1,vertex.color="lightblue",main="Middle East. 2019",vertex.label.cex=.6)
plot(net.as,edge.arrow.size=.1,vertex.color="pink",main="Asia. 2019",vertex.label.cex=.6)
plot(net.am,edge.arrow.size=.1,vertex.color="tomato",main="America. 2019",vertex.label.cex=.6)
plot(net.e,edge.arrow.size=.1,vertex.color="gold",main="Europe. 2019",vertex.label.cex=.4)

net.afD <- net.af - E(net.af)[E(net.af)$International_Domestic == "International"]
plot(net.afD,edge.arrow.size=.1,vertex.color="green",main="Africa: voli Nazionali. 2019",vertex.label.cex=.4)
net.meD <- net.me - E(net.me)[E(net.me)$International_Domestic == "International"]
plot(net.meD,edge.arrow.size=.1,vertex.color="lightblue",main="Middle East: voli Nazionali. 2019",vertex.label.cex=.4)
net.asD <- net.as - E(net.as)[E(net.as)$International_Domestic == "International"]
plot(net.asD,edge.arrow.size=.1,vertex.color="pink",main="Asia: voli Nazionali. 2019",vertex.label.cex=.4)
net.eD <- net.e - E(net.e)[E(net.e)$International_Domestic == "International"]
plot(net.eD,edge.arrow.size=.1,vertex.color="gold",main="Europe: voli Nazionali. 2019",vertex.label.cex=.4)
net.amD <- net.am - E(net.am)[E(net.am)$International_Domestic == "International"]
plot(net.amD,edge.arrow.size=.1,vertex.color="tomato",main="America, voli Nazionali. 2019",vertex.label.cex=.4)
#############################################################################################################################################


#######################
####### PART 2 #######
#######################

## Density --> numero dei link esistenti rispetto a tutti i possibili link. Un grafico in cui ogni nodo è collegato con tutti gli altri ha denistà=1. In generale, più il valore è alto più sono le città che possono essere raggiunte con voli diretti (point-to-point)
edge_density(net,loops=F)
ecount(net)/(vcount(net)*(vcount(net)-1))

## Reciprocity --> frazione dei link bidirezionali
reciprocity(net)
dyad_census(net)
2*dyad_census(net)$mut/ecount(net)

## Transitivity --> triplette transitive (rapporto tra le triplette transitive e le triple potenzialmente transitive; 3*n_tringoli/n_triple)
## Network trattati come undirected!!!
transitivity(net,type="global")
transitivity(as.undirected(net, mode="collapse"))
triad_census(net)

## Diameter --> rappresenta il minimo numero di voli diretti necessari per connettere le due città/aeroporti più remoti nel network.
diameter(net, directed=F,weights=NA)
diameter(net, directed=T,weights=NA)
diameter(net, directed=T)
diam<-get_diameter(net,directed=T)
diam
###highlighting the nodes of the diameter with a color 
vcol <- rep("grey", vcount(net))
vcol[diam] <- "gold"
ecol <- rep("grey95", ecount(net))
ecol[E(net, path=diam)] <- "orange"
# E(net, path=diam) finds edges along a path, here 'diam'

plot(net, vertex.color=vcol, edge.color=ecol, edge.arrow.mode=0, vertex.label.cex=.7, vertex.size=5, main="Diametro del network. 2019")


#############################################################################################################################################


#######################
####### PART 3 #######
#######################

## Gradi dei nodi
### degree centrality (number of direct connections)
dev.off()
deg<-degree(net,mode="all")
par(mar = c(1, 1, 1, 1))
plot(net,vertex.size=deg/7.5,vertex.label=V(net)$Dep, vertex.label.cex=.6,main="Dimensionamento dei nodi per degree. 2019")

par(mar = c(5,5,5,5))
### Sliming down the edges
hist(deg, xlab="Gradi",ylab="numero dei nodi", main  = "Grado dei nodi. 2019")

deg
V(net)$degg <- 0
V(net)$degg <- deg
V(net)$degg
hist(V(net)$degg[V(net)$degg>10], xlab="gradi",ylab="frequency", main  = "Nodi con grado maggiore di 10. 2019")
V(net)[V(net)$degg>10]
#
deg.dist <- degree_distribution(net, cumulative=T, mode="all")
par(mar = c(5, 5, 5, 5))
plot( x=0:max(deg), y=1-deg.dist, pch=19, cex=1.2, col="orange",xlab="Degree",ylab="Cumulative Frequency")

## Centrality e centralization
degree(net, mode="in")
degree(net, mode="all",normalized=T)
gradi <- degree(net, mode="in")
gradiPerc <- gradi/(length(V(net))-1) * 100


centr_degree(net, mode="in", normalized=T)
centr_degree(net, mode="out", normalized=T)
centr_degree(net, mode="all", normalized=T)
#Closeness (centrality based on distance to others in the graph) - Inverse of the node’s average geodesic distance to others in the network.
#normalized=T => the inverse average distance to all reachable vertices
closeness(net, mode="all",normalized=T)
#normalized=F => the inverse of the sum of distances to all reachable vertices.
closeness(net, mode="all",normalized=F)

centr_clo(net, mode="all", normalized=T)


#Betweenness (centrality based on a broker position connecting others) - #Number of geodesics that pass through the node or the edge.
betweenness(net, directed=T, weights=NA)
# Mettere weights=NA equivale a non mettere nulla
betweenness(net, directed=F, normalized = TRUE, weights=NA)
betweenness(net, directed=F, normalized = FALSE, weights=NA)
#betweenness of edges...
#edge_betweenness(net, directed=T, weights=NA)
cbetw <- centr_betw(net, directed=T, normalized=T)$res
centr_betw(net, directed=T, normalized=T)
centr_betw(net, directed=F, normalized=T)
#centralization not divided by the theoretical max 
centr_betw(net, directed=T, normalized=F)
m <- length(V(net))
m
cbetw
cbetwPerc <- cbetw / ((m-1)*(m-2))
cbetwPerc
## Distanza e paths
#Average path length: the mean of the shortest distance between each pair of nodes in the network (#in both directions for directed graphs).
mean_distance(net, directed=F)

mean_distance(net, directed=T)




#################################################
####### Mapping connections with great circles###
#################################################
remove(list=ls())

library(maps)
library(geosphere)
# Mondo
par(mar = c(0, 0, 0, 0))
xlim <- c(-140.938281, 90.601563)
ylim <- c(-75.039321, 75.856229)
map("world", col="grey90", fill=TRUE, bg="white", lwd=0.25, xlim=xlim, ylim=ylim)
#title("Example of airline connections")
mtext(text = "", side = 4, line = -1, adj = 0.01, cex = 0.8)

# Europa
par(mar = c(0, 0, 0, 0))
xlim <- c(-15.938281, 35.601563)
ylim <- c(30.039321, 75.856229)
map("world", col="grey90", fill=TRUE, bg="white", lwd=0.25, xlim=xlim, ylim=ylim)

# Plot connection AMS -> LHR
lat_AMS <- 52.370216
lon_AMS <- 4.895168
lat_LHR <- 51.507351
lon_LHR <- -0.127758
par(mar = c(0, 0, 0, 0))
inter2 <- gcIntermediate(c(lon_AMS, lat_AMS), c(lon_LHR, lat_LHR), n=1000, addStartEnd=TRUE)
lines(inter2, col="blue")

# Adding labels
text((lon_AMS+0.6), (lat_AMS+0.6),"AMS", col="black",cex = .8,font=2)
text((lon_LHR-0.6), (lat_LHR-0.6),"LHR", col="darkorange3",cex = .8,font=2)

# Adding further connctions
lat_AMS <- 52.370216
lon_AMS <- 4.895168
lat_CDG <- 48.856614
lon_CDG <- 2.352222

inter3 <- gcIntermediate(c(lon_AMS, lat_AMS), c(lon_CDG, lat_CDG), n=50, addStartEnd=TRUE)
lines(inter3, col="blue")
text((lon_CDG-0.6), (lat_CDG-0.6),"CDG", col="darkorange3",cex = .8,font=2)

# Africa
xlim <- c(-140.938281, 90.601563)
ylim <- c(-75.039321, 75.856229)
map("world", col="grey90", fill=TRUE, bg="white", lwd=0.25, xlim=xlim, ylim=ylim)
#title("Example of airline connections")
mtext(text = "", side = 4, line = -1, adj = 0.01, cex = 0.8)
xlim2 <- c(-22.83, 45.601563)
ylim2 <- c(-45,42 )
map("world", col="grey90", fill=TRUE, bg="white", lwd=0.25, xlim=xlim2, ylim=ylim2)
lat_JNB <- -26.2041028
lon_JNB <- 28.0473051
lat_CPT <- -33.924869
lon_CPT <- 18.424055

inter4 <- gcIntermediate(c(lon_JNB, lat_JNB), c(lon_CPT, lat_CPT), n=50, addStartEnd=TRUE)
lines(inter4, col="blue")
text((lon_JNB+0.6), (lat_JNB+0.6),"JNB", col="darkorange3",cex = .8,font=2)
text((lon_CPT+0.6), (lat_CPT+0.6),"CPT", col="darkorange3",cex = .8,font=2)

#Mondo
xlim <- c(-140.938281, 170.601563)
ylim <- c(-75.039321, 75.856229)
par(mar = c(0, 0, 0, 0))
map("world", col="grey90", fill=TRUE, bg="white", lwd=0.25, xlim=xlim, ylim=ylim)
#title("Example of airline connections")
mtext(text = "", side = 4, line = -1, adj = 0.01, cex = 0.8)

lat_SYD <- -33.855102
lon_SYD <- 151.237471
lat_AUH <- 24.466667
lon_AUH <- 54.366667
inter4 <- gcIntermediate(c(lon_SYD, lat_SYD), c(lon_AUH, lat_AUH), n=50, addStartEnd=TRUE)
lines(inter4, col="blue")
text((lon_SYD+0.6), (lat_SYD+0.6),"SYD", col="darkorange3",cex = .8,font=2)
text((lon_AUH+0.6), (lat_AUH+0.6),"AUH", col="darkorange3",cex = .8,font=2)

lat_AUH <- 24.466667
lon_AUH <- 54.366667
lat_BNE <- -27.4710107
lon_BNE <- 153.0234489
inter4 <- gcIntermediate(c(lon_AUH, lat_AUH), c(lon_BNE, lat_BNE), n=50, addStartEnd=TRUE)
lines(inter4, col="blue")
text((lon_BNE+0.6), (lat_BNE+0.6),"BNE", col="darkorange3",cex = .8,font=2)

lat_JFK <- 40.779897
lon_JFK <- -73.968565
lat_NBO <- -1.292066
lon_NBO <- 36.821946
inter4 <- gcIntermediate(c(lon_JFK, lat_JFK), c(lon_NBO, lat_NBO), n=50, addStartEnd=TRUE)
lines(inter4, col="blue")
text((lon_JFK+0.6), (lat_JFK+0.6),"JFK", col="darkorange3",cex = .8,font=2)
text((lon_NBO+0.6), (lat_NBO+0.6),"NBO", col="darkorange3",cex = .8,font=2)

lat_MEL <- -33.924869
lon_MEL <- 18.424055
inter4 <- gcIntermediate(c(lon_AUH, lat_AUH), c(lon_MEL, lat_MEL), n=50, addStartEnd=TRUE)
lines(inter4, col="blue")
text((lon_MEL+0.6), (lat_MEL+0.6),"MEL", col="darkorange3",cex = .8,font=2)



#################################################
####### Network analysis 2023             #######
#################################################
#######################
####### PART 1 #######
#######################
rm(list = ls())

par(mar = c(1, 1, 1, 3))
setwd("G:\\Il mio Drive\\UNIBG\\Economia delle reti e dei servizi\\progetto_ERS\\tentativo1")
nodes<-read.csv("KENYA_NODES2023_finale.csv")
links<-read.csv("KENYA_EDGES2023_finale.csv")

nrow(nodes)
length(unique(nodes$id))
nrow(links)
nrow(unique(links[,c("DepAirportCode","ArrAirportCode")]))

### Graphical representation
library(igraph)
net<-graph_from_data_frame(d=links,vertices=nodes,directed=T)

as_edgelist(net,names=T)
as_data_frame(net,what="edges")
as_data_frame(net,what="vertices")

####Plot
plot(net,edge.arrow.size=.1,vertex.size=3,vertex.label.cex=.01, main = "Mappatura dei nodi. 2023")
plot(net,edge.arrow.size=.1,vertex.label=V(net)$Dep,vertex.size=.5,vertex.label.cex=.5, main = "Mappatura dei nodi (Codice aeroporto). 2023")
plot(net, edge.arrow.size=.1, vertex.shape="none", vertex.label=V(net)$Dep, vertex.size=3,vertex.label.font=2, vertex.label.color="gray40",vertex.label.cex=.5, edge.color="gray85", main = "Mappatura dei nodi (Codice aeroporto). 2023")

####Plot with curved links
plot(net,edge.arrow.size=.1,vertex.size=.9,edge.curved=.1,vertex.label.cex=.6,main = "Mappatura dei nodi (Codice aeroporto). Con archi curvi. 2023")

####Plot with yellow nodes
plot(net,edge.arrow.size=.1,edge.curved=0,vertex.color="orange",vertex.frame.color="#555555",vertex.label=V(net)$Dep,vertex.size=4.9,vertex.label.color="black",vertex.label.cex=.5, main = "Mappatura dei nodi (Codice aeroporto). 2023")

####Generation of the color on the basis of the Continent
V(net)$type <- 6
V(net)$type[V(net)$Continent=="Europe"] <- 1
V(net)$type[V(net)$Continent=="Africa"] <- 2
V(net)$type[V(net)$Continent=="Middle East"] <- 3
V(net)$type[V(net)$Continent=="Asia"] <- 4
V(net)$type[V(net)$Continent=="America"] <- 5

colrs<-c("gold", "green", "lightblue", "pink","tomato","black")
V(net)$color<-colrs[V(net)$type]
plot(net,edge.arrow.size=.1,edge.curved=0,vertex.label=V(net)$Dep,vertex.size=4.9,vertex.label.color="black",pt.bg=colrs,vertex.label.cex=.5,vertex.frame.color="white", main= "Mappatura dei nodi, colorati per continente. 2023")
plot(net,edge.arrow.size=.05,edge.curved=0,vertex.label=V(net)$Dep,vertex.size=5,pt.bg=colrs,vertex.label.cex=.005,vertex.frame.color="white", main= "Mappatura dei nodi, colorati per continente. 2023")

V(net)$label<-V(net)$Dep


E(net)$width<-E(net)$POSTI_TOT/10000
V(net)$size<- (log(V(net)$TOTseats)+1)
####Modify arrow dimension and egde/link color
E(net)$arrow.size<-.05
E(net)$edge.color<-"gray80"
par(mar = c(1, 1, 1, 3))

plot(net,vertex.label.cex=.5, main = "Grandezza nodi per posti totali, spessore archi per posti della tratta. 2023")

#analisi lunghezza nodi (km)
netKM <- net
V(netKM)$size<- 5
E(netKM)$width<-E(net)$GCD/10000 +1

cut.offKM<-mean(links$GCD)/10000 + 1
netKM.sp<-delete_edges(netKM,E(netKM)[(GCD/10000 + 0.75)<cut.offKM])
plot(netKM,vertex.label.cex=.5, main="Spessore degli archi dato da lunghezza della tratta. 2023")
plot(netKM.sp,vertex.label.cex=.5, main="Mappa con i collegamenti tra i nodi più distanti. 2023")

par(mar = c(5,5,5,5))
### Sliming down the nodes
hist(nodes$TOTseats, main="Istogramma della grandezza dei nodi per posti totali. 2023", xlab = "posti totali del nodo", ylab = "numero di nodi")
mean(nodes$TOTseats)
sd(nodes$TOTseats)
cut.off2 <- mean(nodes$TOTseats)
net.sp2 <- net - V(net)[(V(net)$TOTseats < cut.off2)]
par(mar = c(1,1,1,1))
plot(net.sp2,edge.arrow.size=.1,edge.color="orange",vertex.color="white",vertex.label.cex=.7, main="mappa dei nodi con il numero di posti totali maggiori della media dei posti totali. 2023")
par(mar = c(5,5,5,5))
postiN <- V(net.sp2)$TOTseats
hist(postiN, main="Istogramma della grandezza dei nodi per posti,\n consideraando solo i nodi con un peso superiore alla media.  2023", xlab = "posti totali del nodo", ylab = "numero dei nodi")
#### Sliming down the network
hist(links$POSTI_TOT, main="Istogramma della grandezza delle tratte per posti totali. 2023", xlab = "posti totali della tratta", ylab = "numero delle tratte")
mean(links$POSTI_TOT)
sd(links$POSTI_TOT)
cut.off<-mean(links$POSTI_TOT)
net.sp<-delete_edges(net,E(net)[POSTI_TOT<cut.off])
par(mar = c(1,1,1,1))
plot(net.sp,edge.arrow.size=.1,edge.color="orange",vertex.color="white",vertex.label.cex=.3,main="mappa delle tratte con posti totali di tratta maggiori alla media. 2023")
par(mar = c(5,5,5,5))
postiE <- E(net.sp)$POSTI_TOT
hist(postiE, main="Istogramma della grandezza delle tratte per posti, \nconsiderando solo le tratte con i posti maggiori alla media. 2023", xlab = "posti totali della tratta", ylab = "numero delle tratte")

par(mar = c(1, 1, 1, 1))
#### Separating the two types of links (e.g., alliances or CSAs)
E(net)$width<-1.5
net.af<-net-V(net)[(V(net)$Continent=="Europe") | (V(net)$Continent=="America") | (V(net)$Continent=="Asia") | (V(net)$Continent=="Middle East")]
net.e<-net-V(net)[V(net)$Continent=="Africa" | V(net)$Continent=="America" | V(net)$Continent=="Asia" | V(net)$Continent=="Middle East"]
net.am<-net-V(net)[V(net)$Continent=="Europe" | V(net)$Continent=="Africa" | V(net)$Continent=="Asia" | V(net)$Continent=="Middle East"]
net.as<-net-V(net)[V(net)$Continent=="Europe" | V(net)$Continent=="America" | V(net)$Continent=="Africa" | V(net)$Continent=="Middle East"]
net.me<-net-V(net)[(V(net)$Continent=="Europe") | (V(net)$Continent=="America") | (V(net)$Continent=="Asia") | (V(net)$Continent=="Africa")]
net.af

dev.off()
plot(net.af,vertex.color="green",main="AFRICA. 2023",vertex.label.cex=.6)
plot(net.me,edge.arrow.size=.1,vertex.color="lightblue",main="Middle East. 2023",vertex.label.cex=.6)
plot(net.as,edge.arrow.size=.1,vertex.color="pink",main="Asia. 2023",vertex.label.cex=.6)
plot(net.am,edge.arrow.size=.1,vertex.color="tomato",main="America. 2023",vertex.label.cex=.6)
plot(net.e,edge.arrow.size=.1,vertex.color="gold",main="Europe. 2023",vertex.label.cex=.4)

net.afD <- net.af - E(net.af)[E(net.af)$International_Domestic == "International"]
plot(net.afD,edge.arrow.size=.1,vertex.color="green",main="Africa: voli Nazionali. 2023",vertex.label.cex=.4)
net.meD <- net.me - E(net.me)[E(net.me)$International_Domestic == "International"]
plot(net.meD,edge.arrow.size=.1,vertex.color="lightblue",main="Middle East: voli Nazionali. 2023",vertex.label.cex=.4)
net.asD <- net.as - E(net.as)[E(net.as)$International_Domestic == "International"]
plot(net.asD,edge.arrow.size=.1,vertex.color="pink",main="Asia: voli Nazionali. 2023",vertex.label.cex=.4)
net.eD <- net.e - E(net.e)[E(net.e)$International_Domestic == "International"]
plot(net.eD,edge.arrow.size=.1,vertex.color="gold",main="Europe: voli Nazionali. 2023",vertex.label.cex=.4)
net.amD <- net.am - E(net.am)[E(net.am)$International_Domestic == "International"]
plot(net.amD,edge.arrow.size=.1,vertex.color="tomato",main="America, voli Nazionali. 2023",vertex.label.cex=.4)
#############################################################################################################################################


#######################
####### PART 2 #######
#######################

setwd("G:\\Il mio Drive\\UNIBG\\Economia delle reti e dei servizi\\progetto_ERS\\tentativo1")
nodesPrincipale<-read.csv("KENYA_NODES2023_principale.csv")
linksPrincipale<-read.csv("KENYA_EDGES2023_principale.csv")
netPrinc<-graph_from_data_frame(d=linksPrincipale,vertices=nodesPrincipale,directed=T)
## Density --> numero dei link esistenti rispetto a tutti i possibili link. Un grafico in cui ogni nodo è collegato con tutti gli altri ha denistà=1. In generale, più il valore è alto più sono le città che possono essere raggiunte con voli diretti (point-to-point)
edge_density(netPrinc,loops=F)
ecount(netPrinc)/(vcount(netPrinc)*(vcount(netPrinc)-1))

## Reciprocity --> frazione dei link bidirezionali
reciprocity(netPrinc)
dyad_census(netPrinc)
2*dyad_census(netPrinc)$mut/ecount(netPrinc)

## Transitivity --> triplette transitive (rapporto tra le triplette transitive e le triple potenzialmente transitive; 3*n_tringoli/n_triple)
## Network trattati come undirected!!!
transitivity(netPrinc,type="global")
transitivity(as.undirected(netPrinc, mode="collapse"))
triad_census(netPrinc)

## Diameter --> rappresenta il minimo numero di voli diretti necessari per connettere le due città/aeroporti più remoti nel network.
diameter(netPrinc, directed=F,weights=NA)
diameter(netPrinc, directed=T,weights=NA)
diameter(netPrinc, directed=T)
diam<-get_diameter(netPrinc,directed=T)
diam
###highlighting the nodes of the diameter with a color 
vcol <- rep("grey", vcount(netPrinc))
vcol[diam] <- "gold"
ecol <- rep("grey50", ecount(netPrinc))
ecol[E(netPrinc, path=diam)] <- "orange"
# E(net, path=diam) finds edges along a path, here 'diam'

E(netPrinc)$width<-1.5
plot(netPrinc, edge.weigth=100, vertex.color=vcol, edge.color=ecol, edge.arrow.mode=0, vertex.label.cex=.7, vertex.size=5, main="Diametro del network. 2023")


#############################################################################################################################################


#######################
####### PART 3 #######
#######################

## Gradi dei nodi
### degree centrality (number of direct connections)
dev.off()
deg<-degree(netPrinc,mode="all")
par(mar = c(1, 1, 1, 1))
plot(netPrinc,vertex.size=deg/7.5,vertex.label=V(net)$Dep, vertex.label.cex=.6,main="Dimensionamento dei nodi per degree, 2023", edge.arrow.size = 0.15)

par(mar = c(5,5,5,5))
### Sliming down the edges
hist(deg, xlab="Gradi",ylab="numero dei nodi", main  = "Grado dei nodi. 2023")

deg
V(netPrinc)$degg <- 0
V(netPrinc)$degg <- deg
V(netPrinc)$degg
hist(V(netPrinc)$degg[V(netPrinc)$degg>10], xlab="gradi",ylab="frequency", main  = "Nodi con grado maggiore di 10. 2023")
V(netPrinc)$degg[V(netPrinc)$degg>10]
maggiori <-length(V(netPrinc)$degg[V(netPrinc)$degg>10])
minori <- length(V(netPrinc)$degg[V(netPrinc)$degg<=10])
Pminori <- minori / length(V(netPrinc)) * 100 
Pminori                          
deg.dist <- degree_distribution(netPrinc, cumulative=T, mode="all")
par(mar = c(7, 7, 7, 7))
plot( x=0:max(deg), y=1-deg.dist, pch=19, cex=1.2, col="orange",xlab="Degree",ylab="Cumulative Frequency")

## Centrality e centralization
gradi <- degree(netPrinc, mode="in")
gradiPerc <- gradi/(length(V(netPrinc))-1) * 100
gradiPerc                
degree(netPrinc, mode="all",normalized=T)
#centralization
centr_degree(netPrinc, mode="in", normalized=T)
centr_degree(netPrinc, mode="out", normalized=T)
centr_degree(netPrinc, mode="all", normalized=T)

#Closeness (centrality based on distance to others in the graph) - Inverse of the node’s average geodesic distance to others in the network.
#normalized=T => the inverse average distance to all reachable vertices
closeness(netPrinc, mode="all",normalized=T)
#normalized=F => the inverse of the sum of distances to all reachable vertices.
closeness(netPrinc, mode="all",normalized=F)

centr_clo(netPrinc, mode="all", normalized=T)
centr_clo(netPrinc, mode="in", normalized=T)



#Betweenness (centrality based on a broker position connecting others) - #Number of geodesics that pass through the node or the edge.
betweenness(netPrinc, directed=T, weights=NA)
# Mettere weights=NA equivale a non mettere nulla
betweenness(netPrinc, directed=F, normalized = TRUE, weights=NA)
betweenness(netPrinc, directed=F, normalized = FALSE, weights=NA)
betweenness(netPrinc, directed=T, normalized = TRUE, weights=NA)

#betweenness of edges...
#edge_betweenness(netPrinc, directed=T, weights=NA)
cbetw <- centr_betw(netPrinc, directed=T, normalized=T)$res
centr_betw(netPrinc, directed=T, normalized=T)
centr_betw(netPrinc, directed=F, normalized=T)
#centralization not divided by the theoretical max 
centr_betw(netPrinc, directed=T, normalized=F)

m <- length(V(netPrinc))
cbetw
cbetwPerc <- cbetw / ((m-1)*(m-2))
cbetwPerc

## Distanza e paths
#Average path length: the mean of the shortest distance between each pair of nodes in the network (#in both directions for directed graphs).
mean_distance(netPrinc, directed=F)

mean_distance(netPrinc, directed=T)




#################################################
#######  Mapping connections with great circle###
#################################################


remove(list=ls())

library(maps)
library(geosphere)
# Mondo
par(mar = c(0, 0, 0, 0))
xlim <- c(-140.938281, 90.601563)
ylim <- c(-75.039321, 75.856229)
map("world", col="grey90", fill=TRUE, bg="white", lwd=0.25, xlim=xlim, ylim=ylim)
#title("Example of airline connections")
mtext(text = "", side = 4, line = -1, adj = 0.01, cex = 0.8)
lat_JFK <- 40.779897
lon_JFK <- -73.968565
lat_NBO <- -1.292066
lon_NBO <- 36.821946
inter4 <- gcIntermediate(c(lon_JFK, lat_JFK), c(lon_NBO, lat_NBO), n=50, addStartEnd=TRUE)
lines(inter4, col="blue")
text((lon_JFK+0.6), (lat_JFK+0.6),"JFK", col="darkorange3",cex = .8,font=2)
text((lon_NBO+0.6), (lat_NBO+0.6),"NBO", col="darkorange3",cex = .8,font=2)
# Europa
par(mar = c(0, 0, 0, 0))
xlim <- c(-15.938281, 35.601563)
ylim <- c(30.039321, 75.856229)
map("world", col="grey90", fill=TRUE, bg="white", lwd=0.25, xlim=xlim, ylim=ylim)

# Adding further connctions
lat_AMS <- 52.370216
lon_AMS <- 4.895168
lat_CDG <- 48.856614
lon_CDG <- 2.352222
par(mar = c(0, 0, 0, 0))
inter2 <- gcIntermediate(c(lon_AMS, lat_AMS), c(lon_CDG, lat_CDG), n=1000, addStartEnd=TRUE)
lines(inter2, col="blue")

# Adding labels
text((lon_AMS+0.6), (lat_AMS+0.6),"AMS", col="black",cex = .8,font=2)
text((lon_CDG-0.6), (lat_CDG-0.6),"CDG", col="darkorange3",cex = .8,font=2)

lat_AMS <- 52.370216
lon_AMS <- 4.895168
lat_FCO <- 41.9027835
lon_FCO <- 12.4963655
inter3 <- gcIntermediate(c(lon_AMS, lat_AMS), c(lon_FCO, lat_FCO), n=50, addStartEnd=TRUE)
lines(inter3, col="blue")
text((lon_FCO-0.6), (lat_FCO-0.6),"FCO", col="darkorange3",cex = .8,font=2)

#Africa
xlim <- c(-140.938281, 90.601563)
ylim <- c(-75.039321, 75.856229)
map("world", col="grey90", fill=TRUE, bg="white", lwd=0.25, xlim=xlim, ylim=ylim)
#title("Example of airline connections")
mtext(text = "", side = 4, line = -1, adj = 0.01, cex = 0.8)
xlim2 <- c(-22.83, 45.601563)
ylim2 <- c(-45,42 )
map("world", col="grey90", fill=TRUE, bg="white", lwd=0.25, xlim=xlim2, ylim=ylim2)
lat_MBA <- -4.043477
lon_MBA <- 39.668206
lat_NBO <- -1.292066
lon_NBO <- 36.821946

inter4 <- gcIntermediate(c(lon_MBA, lat_MBA), c(lon_NBO, lat_NBO), n=50, addStartEnd=TRUE)
lines(inter4, col="blue")
text((lon_MBA+0.6), (lat_MBA+0.6),"MBA", col="darkorange3",cex = .8,font=2)
text((lon_NBO+0.6), (lat_NBO+0.6),"NBO", col="darkorange3",cex = .8,font=2)

